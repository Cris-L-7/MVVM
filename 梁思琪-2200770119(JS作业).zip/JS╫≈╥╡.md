#                                               JS作业

#### 1. 动态改变文档内容

**要求**：创建一个按钮，点击后将文档的 `<h1>` 元素内容改为 "欢迎来到我的网站"，并在页面底部显示当前时间。

`

<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>欢迎页面</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            text-align: center;
            margin: 50px;
        }
        #currentTime {
            margin-top: 20px;
            font-size: 18px;
        }
    </style>
</head>
<body>
    <h1 id="mainTitle">无标题</h1>
    <button id="changeButton">改变标题</button>
    <div id="currentTime"></div>

    <script>
        document.getElementById('changeButton').onclick = function() {
            // 修改 <h1> 元素的内容
            document.getElementById('mainTitle').innerText = '欢迎来到我的网站';

​            // 获取当前时间并格式化
​            const now = new Date();
​            const formattedTime = now.toLocaleString();

​            // 显示当前时间
​            document.getElementById('currentTime').innerText = '当前时间：' + formattedTime;
​        };
​    </script>
</body>
</html>`



#### 2. 表格操作

**要求**：

1. 创建一个表格，允许用户输入数据（姓名和年龄），添加到表格中，并在添加后按**年龄升序**排列。

2. 在表格中添加删除按钮，点击后删除当前行，并在删除后更新表格的行号。

   `

   <!DOCTYPE html>
   <html lang="zh">
   <head>
       <meta charset="UTF-8">
       <title>表格数据排序</title>
       <style>
           table {
               width: 50%;
               margin-top: 20px;
               border: 1px solid #ddd;
               border-collapse: collapse;
           }

   ​        th {
   ​            background-color: #dfeefd;
   ​        }

   ​        th, td {
   ​            padding: 8px;
   ​            text-align: left;
   ​            border: 1px solid #ddd;
   ​        }

   ​        tr:nth-child(even) {
   ​            background-color: #f2f2f2;
   ​        }

   ​        .add-button {
   ​            margin-top: 20px;
   ​        }
   ​    </style>
   </head>
   <body>
   ​    <table id="myTable">
   ​        <tr>
   ​            <th>姓名</th>
   ​            <th>年龄</th>
   ​            <th>操作</th>
   ​        </tr>
   ​    </table>
   ​    <input type="text" id="nameInput" placeholder="姓名" />
   ​    <input type="number" id="ageInput" placeholder="年龄" />
   ​    <button id="addRow" class="add-button">添加数据</button>

       <script>
           document.getElementById('addRow').onclick = function() {
               const name = document.getElementById('nameInput').value;
               const age = document.getElementById('ageInput').value;

   ​            if (name && age) {
   ​                const table = document.getElementById('myTable');
   ​                const newRow = table.insertRow(-1);
   ​                const cell1 = newRow.insertCell(0);
   ​                const cell2 = newRow.insertCell(1);
   ​                const cell3 = newRow.insertCell(2);

   ​                cell1.innerHTML = name;
   ​                cell2.innerHTML = age;
   ​                cell3.innerHTML = '<button onclick="deleteRow(this)">删除</button>';

   ​                sortTable();
   ​            }
   ​        };

   ​        function deleteRow(button) {
   ​            const row = button.parentNode.parentNode;
   ​            row.parentNode.removeChild(row);
   ​            updateRowNumbers();
   ​        }

   ​        function sortTable() {
   ​            const table = document.getElementById('myTable');
   ​            const rows = Array.from(table.rows).slice(1); // 忽略表头

   ​            rows.sort((a, b) => {
   ​                const ageA = parseInt(a.cells[1].innerText);
   ​                const ageB = parseInt(b.cells[1].innerText);
   ​                return ageA - ageB;
   ​            });

   ​            rows.forEach(row => table.appendChild(row));
   ​        }

   ​        function updateRowNumbers() {
   ​            const rows = document.querySelectorAll('#myTable tr');
   ​            rows.forEach((row, index) => {
   ​                if (index > 0) { // 忽略表头
   ​                    row.cells[0].innerText = index;
   ​                }
   ​            });
   ​        }
   ​    </script>
   </body>
   </html>`
   
   
   
   #### 3. 列表操作
   
   **要求：**创建一个无序列表，允许用户输入新项并添加到列表中。每个列表项旁边有一个编辑按钮，点击后可以修改该项的内容，还有一个删除按钮，点击后可以删除该项。
   
   `
   
   <!DOCTYPE html>
   <html lang="zh">
   <head>
       <meta charset="UTF-8">
       <title>动态更新和删除列表项</title>
       <style>
           body {
               font-family: Arial, sans-serif;
               background-color: #f4f4f4;
               margin: 0;
               padding: 20px;
           }
           h1 {
               text-align: center;
               color: #333;
           }
           ul {
               list-style-type: none;
               padding: 0;
               max-width: 600px;
               margin: 20px auto;
               background: white;
               border-radius: 5px;
               box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
           }
           li {
               padding: 15px;
               border-bottom: 1px solid #ddd;
               display: flex;
               justify-content: space-between;
               align-items: center;
           }
           li:last-child {
               border-bottom: none;
           }
           button {
               background-color: #007BFF;
               color: white;
               border: none;
               border-radius: 5px;
               padding: 8px 12px;
               cursor: pointer;
               transition: background-color 0.3s;
           }
           button:hover {
               background-color: #0056b3;
           }
           input[type="text"] {
               padding: 10px;
               width: 400px;
               border: 1px solid #ccc;
               border-radius: 5px;
               margin-right: 10px;
           }
           .input-content {
               display: flex;
               justify-content: center;
               margin-top: 20px;
           }
       </style>
   </head>
   <body>
       <h1>动态列表管理</h1>
       <ul id="myList"></ul>
       <div class="input-content">
           <input type="text" id="itemInput" placeholder="新项">
           <button id="addItem">添加项</button>
       </div>
   
       <script>
           const addItemButton = document.getElementById('addItem');
           const itemInput = document.getElementById('itemInput');
           const myList = document.getElementById('myList');
   
   ​        // 添加新项
   ​        addItemButton.addEventListener('click', function() {
   ​            const inputValue = itemInput.value.trim();
   ​            if (inputValue === "") {
   ​                alert("请输入项内容");
   ​                return;
   ​            }
   
   ​            const li = document.createElement('li');
   ​            li.textContent = inputValue;
   
   ​            const editButton = document.createElement('button');
   ​            editButton.textContent = "编辑";
   ​            editButton.onclick = function() {
   ​                const newValue = prompt("修改项内容:", inputValue);
   ​                if (newValue !== null && newValue.trim() !== "") {
   ​                    inputValue = newValue.trim();
   ​                    li.firstChild.textContent = inputValue;
   ​                }
   ​            };
   
   ​            const deleteButton = document.createElement('button');
   ​            deleteButton.textContent = "删除";
   ​            deleteButton.onclick = function() {
   ​                myList.removeChild(li);
   ​            };
   
   ​            li.appendChild(editButton);
   ​            li.appendChild(deleteButton);
   ​            myList.appendChild(li);
   ​            itemInput.value = ""; // 清空输入框
   ​        });
   ​    </script>
   </body>
   </html>`
   
   #### 3. 列表操作
   
   **要求：**创建一个无序列表，允许用户输入新项并添加到列表中。每个列表项旁边有一个编辑按钮，点击后可以修改该项的内容，还有一个删除按钮，点击后可以删除该项。
   
   `
   
   <!DOCTYPE html>
   <html lang="zh">
   <head>
       <meta charset="UTF-8">
       <title>动态更新和删除列表项</title>
       <style>
           body {
               font-family: Arial, sans-serif;
               background-color: #f4f4f4;
               margin: 0;
               padding: 20px;
           }
           h1 {
               text-align: center;
               color: #333;
           }
           ul {
               list-style-type: none;
               padding: 0;
               max-width: 600px;
               margin: 20px auto;
               background: white;
               border-radius: 5px;
               box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
           }
           li {
               padding: 15px;
               border-bottom: 1px solid #ddd;
               display: flex;
               justify-content: space-between;
               align-items: center;
           }
           li:last-child {
               border-bottom: none;
           }
           button {
               background-color: #007BFF;
               color: white;
               border: none;
               border-radius: 5px;
               padding: 8px 12px;
               cursor: pointer;
               transition: background-color 0.3s;
           }
           button:hover {
               background-color: #0056b3;
           }
           input[type="text"] {
               padding: 10px;
               width: 400px;
               border: 1px solid #ccc;
               border-radius: 5px;
               margin-right: 10px;
           }
           .input-content {
               display: flex;
               justify-content: center;
               margin-top: 20px;
           }
       </style>
   </head>
   <body>
       <h1>动态列表管理</h1>
       <ul id="myList"></ul>
       <div class="input-content">
           <input type="text" id="itemInput" placeholder="新项">
           <button id="addItem">添加项</button>
       </div>
   
       <script>
           const addItemButton = document.getElementById('addItem');
           const itemInput = document.getElementById('itemInput');
           const myList = document.getElementById('myList');
   
   ​        // 添加新项
   ​        addItemButton.addEventListener('click', function() {
   ​            const inputValue = itemInput.value.trim();
   ​            if (inputValue === "") {
   ​                alert("请输入项内容");
   ​                return;
   ​            }
   
   ​            const li = document.createElement('li');
   ​            li.textContent = inputValue;
   
   ​            const editButton = document.createElement('button');
   ​            editButton.textContent = "编辑";
   ​            editButton.onclick = function() {
   ​                const newValue = prompt("修改项内容:", inputValue);
   ​                if (newValue !== null && newValue.trim() !== "") {
   ​                    inputValue = newValue.trim();
   ​                    li.firstChild.textContent = inputValue;
   ​                }
   ​            };
   
   ​            const deleteButton = document.createElement('button');
   ​            deleteButton.textContent = "删除";
   ​            deleteButton.onclick = function() {
   ​                myList.removeChild(li);
   ​            };
   
   ​            li.appendChild(editButton);
   ​            li.appendChild(deleteButton);
   ​            myList.appendChild(li);
   ​            itemInput.value = ""; // 清空输入框
   ​        });
   ​    </script>
   </body>
   </html>`